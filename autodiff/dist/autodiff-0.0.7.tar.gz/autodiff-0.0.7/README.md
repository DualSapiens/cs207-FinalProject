# autodiff package

This is a package that implements automatic differentation to support other applications.

It is hosted at https://github.com/DualSapiens/cs207-FinalProject.
