import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

# with open('requirements.txt') as f:
#     requirements = f.read().splitlines()

setuptools.setup(
    name="autodiff",
    version="0.0.4",
    author="DualSapiens",
    author_email="",
    description="A package for automatic differentiation",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/DualSapiens/cs207-FinalProject",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires=["atomicwrites>=1",
                    "attrs>=18",
                    "coverage>=4",
                    "more-itertools>=4",
                    "numpy>=1",
                    "pluggy>=0",
                    "py>=1",
                    "pytest>=3",
                    "pytest-cov>=2",
                    "six>=1"]
    # install_requires=requirements
)
